/*
 * 함수를 만드는 방법 2가지
 * 호출시 alert창에 Hello world 프린트 
 */