
greeting();

var greeting = function(){
	alert('Hello World!');
}

// 결과 예측 및 재작성